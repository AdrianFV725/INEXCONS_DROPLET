# Autenticación en INEXCONS

Este documento describe las funcionalidades de autenticación implementadas en el sistema INEXCONS.

## Endpoints de Autenticación

### Inicio de Sesión

**URL:** `/api/login`
**Método:** `POST`
**Datos requeridos:**

```json
{
    "email": "correo@ejemplo.com",
    "password": "contraseña"
}
```

**Respuesta exitosa:**

```json
{
    "status": "success",
    "message": "Inicio de sesión exitoso",
    "user": {
        "id": 1,
        "name": "Nombre Usuario",
        "email": "correo@ejemplo.com",
        "email_verified_at": null,
        "created_at": "2025-03-09T21:44:05.000000Z",
        "updated_at": "2025-03-09T21:44:05.000000Z"
    },
    "token": "1|3mtJ7olp51UnsOTdswCe8fQMPUzmFJXXUV2pDzQg39e34693"
}
```

**Respuesta de error:**

```json
{
    "status": "error",
    "message": "Credenciales incorrectas"
}
```

### Recuperación de Contraseña

**URL:** `/api/recuperar-password`
**Método:** `POST`
**Datos requeridos:**

```json
{
    "email": "correo@ejemplo.com"
}
```

**Respuesta exitosa:**

```json
{
    "status": "success",
    "message": "Se ha enviado una nueva contraseña a tu correo electrónico"
}
```

**Respuesta de error:**

```json
{
    "status": "error",
    "message": "No se encontró un usuario con ese correo electrónico"
}
```

### Cerrar Sesión

**URL:** `/api/logout`
**Método:** `POST`
**Encabezados requeridos:**

```
Authorization: Bearer {token}
```

**Respuesta exitosa:**

```json
{
    "status": "success",
    "message": "Sesión cerrada correctamente"
}
```

### Obtener Usuario Actual

**URL:** `/api/user`
**Método:** `GET`
**Encabezados requeridos:**

```
Authorization: Bearer {token}
```

**Respuesta exitosa:**

```json
{
    "id": 1,
    "name": "Nombre Usuario",
    "email": "correo@ejemplo.com",
    "email_verified_at": null,
    "created_at": "2025-03-09T21:44:05.000000Z",
    "updated_at": "2025-03-09T21:44:05.000000Z"
}
```

## Uso en el Frontend

Para usar estas funcionalidades en el frontend, debes hacer lo siguiente:

1. **Inicio de sesión:**

```javascript
async function login(email, password) {
    try {
        const response = await fetch("http://localhost:8000/api/login", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify({ email, password }),
        });

        const data = await response.json();

        if (data.status === "success") {
            // Guardar el token en localStorage
            localStorage.setItem("token", data.token);
            localStorage.setItem("user", JSON.stringify(data.user));
            return data;
        } else {
            throw new Error(data.message);
        }
    } catch (error) {
        console.error("Error al iniciar sesión:", error);
        throw error;
    }
}
```

2. **Recuperación de contraseña:**

```javascript
async function recuperarPassword(email) {
    try {
        const response = await fetch(
            "http://localhost:8000/api/recuperar-password",
            {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify({ email }),
            }
        );

        const data = await response.json();

        if (data.status === "success") {
            return data;
        } else {
            throw new Error(data.message);
        }
    } catch (error) {
        console.error("Error al recuperar contraseña:", error);
        throw error;
    }
}
```

3. **Cerrar sesión:**

```javascript
async function logout() {
    try {
        const token = localStorage.getItem("token");

        if (!token) {
            throw new Error("No hay sesión activa");
        }

        const response = await fetch("http://localhost:8000/api/logout", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                Authorization: `Bearer ${token}`,
            },
        });

        const data = await response.json();

        if (data.status === "success") {
            // Eliminar el token y el usuario de localStorage
            localStorage.removeItem("token");
            localStorage.removeItem("user");
            return data;
        } else {
            throw new Error(data.message);
        }
    } catch (error) {
        console.error("Error al cerrar sesión:", error);
        throw error;
    }
}
```

4. **Obtener usuario actual:**

```javascript
async function getCurrentUser() {
    try {
        const token = localStorage.getItem("token");

        if (!token) {
            throw new Error("No hay sesión activa");
        }

        const response = await fetch("http://localhost:8000/api/user", {
            method: "GET",
            headers: {
                "Content-Type": "application/json",
                Authorization: `Bearer ${token}`,
            },
        });

        return await response.json();
    } catch (error) {
        console.error("Error al obtener usuario actual:", error);
        throw error;
    }
}
```

## Credenciales de Prueba

Para probar la autenticación, puedes usar las siguientes credenciales:

-   **Email:** eugeniosflores@gmail.com
-   **Contraseña:** Roberto0203 (o la contraseña temporal enviada por correo si ya has usado la recuperación de contraseña)
