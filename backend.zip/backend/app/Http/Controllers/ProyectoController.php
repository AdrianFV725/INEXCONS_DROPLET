<?php

namespace App\Http\Controllers;

use App\Models\Proyecto;
use App\Models\Contratista;
use App\Models\Concepto;
use App\Models\Pago;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Log;

class ProyectoController extends Controller
{
    public function index()
    {
        try {
            $proyectos = Proyecto::with(['pagos'])->get();
            return response()->json($proyectos);
        } catch (\Exception $e) {
            return response()->json(['error' => 'Error al obtener los proyectos: ' . $e->getMessage()], 500);
        }
    }

    public function store(Request $request)
    {
        try {
            DB::beginTransaction();

            $validated = $request->validate([
                'nombre' => 'required|string|max:255',
                'montoTotal' => 'required|numeric|min:0',
                'iva' => 'required|numeric|min:0',
                'fechaInicio' => 'required|date',
                'fechaFinalizacion' => 'required|date|after_or_equal:fechaInicio',
                'anticipo' => 'required|numeric|min:0'
            ]);

            $proyecto = Proyecto::create($validated);

            DB::commit();
            return response()->json($proyecto, 201);
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json(['error' => 'Error al crear el proyecto: ' . $e->getMessage()], 500);
        }
    }

    public function show($id)
    {
        try {
            $proyecto = Proyecto::with(['pagos' => function ($query) {
                $query->orderBy('fecha', 'desc');
            }, 'contratistas', 'trabajadores'])->findOrFail($id);

            return response()->json($proyecto);
        } catch (\Illuminate\Database\Eloquent\ModelNotFoundException $e) {
            return response()->json(['error' => 'Proyecto no encontrado'], 404);
        } catch (\Exception $e) {
            return response()->json(['error' => 'Error al obtener el proyecto: ' . $e->getMessage()], 500);
        }
    }

    public function update(Request $request, $id)
    {
        try {
            DB::beginTransaction();

            $proyecto = Proyecto::findOrFail($id);

            $validated = $request->validate([
                'nombre' => 'required|string|max:255',
                'montoTotal' => 'required|numeric|min:0',
                'iva' => 'required|numeric|min:0',
                'fechaInicio' => 'required|date',
                'fechaFinalizacion' => 'required|date|after_or_equal:fechaInicio',
                'anticipo' => 'required|numeric|min:0'
            ]);

            $proyecto->update($validated);

            // Actualizar contratistas si se proporcionan
            if ($request->has('contratistas')) {
                $contratistas = json_decode($request->contratistas, true);
                $proyecto->contratistas()->sync($contratistas);
            }

            DB::commit();
            return response()->json($proyecto->load(['pagos', 'contratistas']));
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json(['error' => 'Error al actualizar el proyecto: ' . $e->getMessage()], 500);
        }
    }

    public function destroy($id)
    {
        try {
            DB::beginTransaction();

            $proyecto = Proyecto::findOrFail($id);
            $proyecto->delete();

            DB::commit();
            return response()->json(null, 204);
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json(['error' => 'Error al eliminar el proyecto: ' . $e->getMessage()], 500);
        }
    }

    public function addPayment(Request $request, $id)
    {
        try {
            DB::beginTransaction();

            $proyecto = Proyecto::findOrFail($id);

            $validated = $request->validate([
                'monto' => 'required|numeric|min:0',
                'fecha' => 'required|date',
                'descripcion' => 'required|string'
            ]);

            $pago = $proyecto->pagos()->create($validated);

            DB::commit();
            return response()->json($pago, 201);
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json(['error' => 'Error al registrar el pago: ' . $e->getMessage()], 500);
        }
    }

    public function updateContractors(Request $request, $id)
    {
        try {
            DB::beginTransaction();

            $proyecto = Proyecto::findOrFail($id);

            if ($request->has('contratistas')) {
                $contratistas = json_decode($request->contratistas, true);
                $proyecto->contratistas()->sync($contratistas);
            }

            DB::commit();
            return response()->json($proyecto->load(['contratistas']), 200);
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json(['error' => 'Error al actualizar los contratistas: ' . $e->getMessage()], 500);
        }
    }

    /**
     * Obtener todos los conceptos de un proyecto
     */
    public function getConceptos($id)
    {
        try {
            $proyecto = Proyecto::findOrFail($id);
            $conceptos = $proyecto->conceptos()->with(['contratista', 'pagos'])->get();

            return response()->json([
                'success' => true,
                'data' => $conceptos
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Error al obtener los conceptos: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Obtener los conceptos de un contratista en un proyecto específico
     */
    public function getConceptosByContratista($proyectoId, $contratistaId)
    {
        try {
            $proyecto = Proyecto::findOrFail($proyectoId);
            $contratista = Contratista::findOrFail($contratistaId);

            // Verificar que el contratista esté asignado al proyecto
            $contratistaAsignado = $proyecto->contratistas()->where('contratista_id', $contratistaId)->exists();

            if (!$contratistaAsignado) {
                return response()->json([
                    'success' => false,
                    'message' => 'El contratista no está asignado a este proyecto'
                ], 422);
            }

            $conceptos = Concepto::where('proyecto_id', $proyectoId)
                ->where('contratista_id', $contratistaId)
                ->with(['pagos'])
                ->get();

            return response()->json([
                'success' => true,
                'data' => $conceptos
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Error al obtener los conceptos: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Crear un nuevo concepto para un proyecto y contratista específicos
     */
    public function createConcepto(Request $request, $proyectoId, $contratistaId)
    {
        try {
            $proyecto = Proyecto::findOrFail($proyectoId);
            $contratista = Contratista::findOrFail($contratistaId);

            // Verificar que el contratista esté asignado al proyecto
            $contratistaAsignado = $proyecto->contratistas()->where('contratista_id', $contratistaId)->exists();

            if (!$contratistaAsignado) {
                return response()->json([
                    'success' => false,
                    'message' => 'El contratista no está asignado a este proyecto'
                ], 422);
            }

            $validated = $request->validate([
                'nombre' => 'required|string|max:255',
                'descripcion' => 'nullable|string',
                'monto_total' => 'required|numeric|min:0',
                'anticipo' => 'nullable|numeric|min:0',
            ]);

            $validated['contratista_id'] = $contratistaId;
            $validated['proyecto_id'] = $proyectoId;

            DB::beginTransaction();

            $concepto = Concepto::create($validated);

            // Si se proporcionó un anticipo, crear un pago de anticipo
            if (isset($validated['anticipo']) && $validated['anticipo'] > 0) {
                try {
                    $concepto->pagos()->create([
                        'monto' => $validated['anticipo'],
                        'fecha' => now(),
                        'descripcion' => 'Anticipo para el concepto: ' . $concepto->nombre,
                        'es_anticipo' => true,
                        'proyecto_id' => $proyectoId
                    ]);
                } catch (\Exception $e) {
                    Log::error('Error al crear pago de anticipo: ' . $e->getMessage());
                    throw $e;
                }
            }

            DB::commit();

            return response()->json([
                'success' => true,
                'message' => 'Concepto creado exitosamente',
                'data' => $concepto->load(['pagos'])
            ], 201);
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json([
                'success' => false,
                'message' => 'Error al crear el concepto: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Obtener todos los contratistas de un proyecto con sus conceptos
     */
    public function getContratistasWithConceptos($id)
    {
        try {
            $proyecto = Proyecto::findOrFail($id);
            $contratistas = $proyecto->contratistas()->get();

            $result = [];
            foreach ($contratistas as $contratista) {
                $conceptos = Concepto::where('proyecto_id', $id)
                    ->where('contratista_id', $contratista->id)
                    ->with(['pagos'])
                    ->get();

                $result[] = [
                    'contratista' => $contratista,
                    'conceptos' => $conceptos
                ];
            }

            return response()->json([
                'success' => true,
                'data' => $result
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Error al obtener los contratistas con conceptos: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Obtener estadísticas de proyectos
     */
    public function stats()
    {
        try {
            Log::info('Iniciando stats en ProyectoController');

            $total = Proyecto::count();
            Log::info('Total de proyectos: ' . $total);

            $activos = Proyecto::where('fechaFinalizacion', '>=', now())->count();
            Log::info('Proyectos activos: ' . $activos);

            $montoTotal = Proyecto::sum('montoTotal');
            Log::info('Monto total: ' . $montoTotal);

            // Calcular monto pendiente (montoTotal - pagos realizados)
            $pagosRealizados = DB::table('pagos')
                ->where('tipo', 'cliente')
                ->sum('monto');
            Log::info('Pagos realizados: ' . $pagosRealizados);

            $montoPendiente = $montoTotal - $pagosRealizados;
            Log::info('Monto pendiente: ' . $montoPendiente);

            // Obtener proyectos por mes (últimos 6 meses)
            $proyectosPorMes = DB::table('proyectos')
                ->select(DB::raw("strftime('%m', fechaInicio) as mes, strftime('%Y', fechaInicio) as año, COUNT(*) as total"))
                ->whereDate('fechaInicio', '>=', now()->subMonths(6))
                ->groupBy('año', 'mes')
                ->orderBy('año')
                ->orderBy('mes')
                ->get();
            Log::info('Proyectos por mes: ' . $proyectosPorMes->count());

            // Obtener pagos por mes (últimos 6 meses)
            $pagosPorMes = DB::table('pagos')
                ->select(DB::raw("strftime('%m', fecha) as mes, strftime('%Y', fecha) as año, SUM(monto) as total"))
                ->whereDate('fecha', '>=', now()->subMonths(6))
                ->groupBy('año', 'mes')
                ->orderBy('año')
                ->orderBy('mes')
                ->get();
            Log::info('Pagos por mes: ' . $pagosPorMes->count());

            $response = [
                'total' => $total,
                'activos' => $activos,
                'montoTotal' => $montoTotal,
                'montoPendiente' => $montoPendiente,
                'proyectosPorMes' => $proyectosPorMes,
                'pagosPorMes' => $pagosPorMes
            ];

            Log::info('Respuesta de stats en ProyectoController: ' . json_encode($response));

            return response()->json($response);
        } catch (\Exception $e) {
            Log::error('Error en ProyectoController@stats: ' . $e->getMessage());
            Log::error('Trace: ' . $e->getTraceAsString());

            // Devolver valores vacíos en caso de error
            return response()->json([
                'total' => 0,
                'activos' => 0,
                'montoTotal' => 0,
                'montoPendiente' => 0,
                'proyectosPorMes' => [],
                'pagosPorMes' => []
            ], 500);
        }
    }

    /**
     * Agregar un pago directo del cliente al proyecto
     */
    public function addClientePayment(Request $request, $id)
    {
        try {
            DB::beginTransaction();

            $proyecto = Proyecto::findOrFail($id);

            $validated = $request->validate([
                'monto' => 'required|numeric|min:0',
                'fecha' => 'required|date',
                'descripcion' => 'required|string'
            ]);

            // Agregar tipo 'cliente' al pago
            $validated['tipo'] = 'cliente';
            $validated['proyecto_id'] = $id;

            // Crear el pago directamente en la tabla pagos
            $pago = Pago::create($validated);

            DB::commit();
            return response()->json([
                'success' => true,
                'message' => 'Pago registrado correctamente',
                'data' => $pago
            ], 201);
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json([
                'success' => false,
                'message' => 'Error al registrar el pago: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Obtener todos los pagos directos del cliente para un proyecto
     */
    public function getClientePayments($id)
    {
        try {
            $proyecto = Proyecto::findOrFail($id);

            // Obtener pagos directos del cliente (tipo = 'cliente')
            $pagos = Pago::where('proyecto_id', $id)
                ->where('tipo', 'cliente')
                ->orderBy('fecha', 'desc')
                ->get();

            return response()->json([
                'success' => true,
                'message' => 'Pagos del cliente obtenidos correctamente',
                'data' => $pagos
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Error al obtener los pagos: ' . $e->getMessage()
            ], 500);
        }
    }
}
