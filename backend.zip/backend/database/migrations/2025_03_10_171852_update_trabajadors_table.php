<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        // Primero eliminamos el índice único
        Schema::table('trabajadors', function (Blueprint $table) {
            $table->dropUnique('trabajadors_rut_unique');
        });

        // Luego modificamos la tabla
        Schema::table('trabajadors', function (Blueprint $table) {
            // Eliminar columnas antiguas
            $table->dropColumn(['rut', 'direccion', 'email', 'especialidad', 'descripcion']);

            // Agregar nuevas columnas
            $table->string('apellidos')->after('nombre');
            $table->date('fecha_contratacion')->after('apellidos');
            $table->decimal('sueldo_base', 10, 2)->after('fecha_contratacion');
            $table->string('rfc')->nullable()->after('telefono');
            $table->string('ine')->nullable()->after('rfc');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('trabajadors', function (Blueprint $table) {
            // Eliminar nuevas columnas
            $table->dropColumn(['apellidos', 'fecha_contratacion', 'sueldo_base', 'rfc', 'ine']);

            // Restaurar columnas antiguas
            $table->string('rut')->after('nombre');
            $table->string('direccion')->nullable()->after('rut');
            $table->string('email')->nullable()->after('telefono');
            $table->string('especialidad')->nullable()->after('email');
            $table->text('descripcion')->nullable()->after('especialidad');
        });

        // Restaurar el índice único
        Schema::table('trabajadors', function (Blueprint $table) {
            $table->unique('rut');
        });
    }
};
