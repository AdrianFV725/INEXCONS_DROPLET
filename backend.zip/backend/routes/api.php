<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ProyectoController;
use App\Http\Controllers\ContratistaController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\ConceptoController;
use App\Http\Controllers\TrabajadorController;
use App\Http\Controllers\EspecialidadController;

// Ruta de prueba
Route::get('/test', function () {
    return response()->json(['message' => 'API funcionando correctamente']);
});

// Rutas de autenticación
Route::post('/login', [AuthController::class, 'login']);
Route::post('/recuperar-password', [AuthController::class, 'recuperarPassword']);

// Rutas de especialidades (sin autenticación)
Route::prefix('especialidades')->group(function () {
    Route::get('/', [EspecialidadController::class, 'index']);
    Route::post('/', [EspecialidadController::class, 'store']);
    Route::get('/{id}', [EspecialidadController::class, 'show']);
    Route::put('/{id}', [EspecialidadController::class, 'update']);
    Route::delete('/{id}', [EspecialidadController::class, 'destroy']);
});

// Rutas protegidas
Route::middleware('auth:sanctum')->group(function () {
    Route::post('/logout', [AuthController::class, 'logout']);
    Route::get('/user', [AuthController::class, 'user']);

    // Rutas de proyectos
    Route::prefix('proyectos')->group(function () {
        Route::get('/', [ProyectoController::class, 'index']);
        Route::post('/', [ProyectoController::class, 'store']);
        Route::get('/stats', [ProyectoController::class, 'stats']);
        Route::get('/{id}', [ProyectoController::class, 'show']);
        Route::put('/{id}', [ProyectoController::class, 'update']);
        Route::delete('/{id}', [ProyectoController::class, 'destroy']);
        Route::post('/{id}/pagos', [ProyectoController::class, 'addPayment']);
        Route::post('/{id}/pagos-cliente', [ProyectoController::class, 'addClientePayment']);
        Route::get('/{id}/pagos-cliente', [ProyectoController::class, 'getClientePayments']);
        Route::put('/{id}/contratistas', [ProyectoController::class, 'updateContractors']);

        // Nuevas rutas para conceptos en proyectos
        Route::get('/{id}/conceptos', [ProyectoController::class, 'getConceptos']);
        Route::get('/{id}/contratistas-conceptos', [ProyectoController::class, 'getContratistasWithConceptos']);
        Route::get('/{proyectoId}/contratistas/{contratistaId}/conceptos', [ProyectoController::class, 'getConceptosByContratista']);
        Route::post('/{proyectoId}/contratistas/{contratistaId}/conceptos', [ProyectoController::class, 'createConcepto']);
    });

    // Rutas de contratistas
    Route::prefix('contratistas')->group(function () {
        Route::get('/', [ContratistaController::class, 'index']);
        Route::post('/', [ContratistaController::class, 'store']);
        Route::get('/stats', [ContratistaController::class, 'stats']);
        Route::get('/{id}', [ContratistaController::class, 'show']);
        Route::put('/{id}', [ContratistaController::class, 'update']);
        Route::delete('/{id}', [ContratistaController::class, 'destroy']);
        Route::post('/{id}/proyectos/{proyectoId}', [ContratistaController::class, 'assignToProject']);
        Route::delete('/{id}/proyectos/{proyectoId}', [ContratistaController::class, 'removeFromProject']);
        Route::delete('/{id}/documentos/{documentId}', [ContratistaController::class, 'deleteDocument']);

        // Nuevas rutas para conceptos en contratistas
        Route::get('/{id}/conceptos', [ContratistaController::class, 'getConceptos']);
        Route::get('/{contratistaId}/proyectos/{proyectoId}/conceptos', [ContratistaController::class, 'getConceptosByProyecto']);
        Route::post('/{contratistaId}/proyectos/{proyectoId}/conceptos', [ContratistaController::class, 'createConcepto']);
    });

    // Rutas de conceptos
    Route::prefix('conceptos')->group(function () {
        Route::get('/', [ConceptoController::class, 'index']);
        Route::post('/', [ConceptoController::class, 'store']);
        Route::get('/{id}', [ConceptoController::class, 'show']);
        Route::put('/{id}', [ConceptoController::class, 'update']);
        Route::delete('/{id}', [ConceptoController::class, 'destroy']);

        // Rutas para pagos de conceptos
        Route::get('/{id}/pagos', [ConceptoController::class, 'getPayments']);
        Route::post('/{id}/pagos', [ConceptoController::class, 'addPayment']);
    });

    // Rutas de trabajadores
    Route::prefix('trabajadores')->group(function () {
        Route::get('/', [TrabajadorController::class, 'index']);
        Route::post('/', [TrabajadorController::class, 'store']);
        Route::get('/stats', [TrabajadorController::class, 'stats']);
        Route::get('/{id}', [TrabajadorController::class, 'show']);
        Route::put('/{id}', [TrabajadorController::class, 'update']);
        Route::delete('/{id}', [TrabajadorController::class, 'destroy']);

        // Rutas para asignación a proyectos
        Route::post('/{id}/proyectos', [TrabajadorController::class, 'asignarProyecto']);
        Route::delete('/{id}/proyectos', [TrabajadorController::class, 'desasignarProyecto']);
        Route::get('/{id}/proyectos', [TrabajadorController::class, 'proyectos']);

        // Rutas para pagos de trabajadores
        Route::post('/{id}/pagos', [TrabajadorController::class, 'registrarPago']);
        Route::get('/{id}/pagos', [TrabajadorController::class, 'pagos']);
    });
});
