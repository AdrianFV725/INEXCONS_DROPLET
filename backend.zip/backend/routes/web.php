<?php

use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('welcome');
});

// Agregar una ruta de login para evitar el error de redirección
Route::get('/login', function () {
    return response()->json(['message' => 'Por favor, inicia sesión a través de la API'], 401);
})->name('login');
